import numpy as np
import matplotlib.pyplot as plt
import pyamg
import time
import scipy.sparse as sp
from scipy.stats import linregress

#(\beta u_x)_x=f(x)
# interface x=\alpha=1/2

#define beta(x)
def beta(t):
    if 0<t<=1/2:
        result=1
    else:
        result=2
    return result


beta_plus=2 #beta>1/2
beta_minus=1 #beta<1/2

# define f(x)
def fun(t):# f(x)
    result=12*t**2
    return result

# define analytical solution
def fun_analytical(t):# analytical solution
    if 0<t<1/2:
        result=t**4/beta_minus
    else:
        result=t**4/beta_plus+(1/beta_minus-1/beta_plus)*(1/2)**4
    return result

def interface_order_drop(N):
    x = np.linspace(0, 1, N + 1)
    h = x[1] - x[0]

    # define boundary conditions
    u_0 = 0
    u_end = 1 / beta_plus + (1 / beta_minus - 1 / beta_plus) * (1 / 2) ** 4

    # constrcut matrix A
    # regular points
    # A=np.zeros((N-1,N-1))
    A = sp.lil_matrix((N - 1, N - 1))
    A[0, 0] = -1 / h ** 2 * (beta((x[0] + x[1]) / 2) + beta((x[1] + x[2]) / 2))
    A[0, 1] = (beta((x[1] + x[2]) / 2)) / h ** 2
    A[N - 2, N - 2] = -1 / h ** 2 * (beta((x[N - 2] + x[N - 1]) / 2) + beta((x[N - 1] + x[N]) / 2))
    A[N - 2, N - 3] = (beta((x[N - 2] + x[N - 1]) / 2)) / h ** 2
    for i in range(1, N - 2):
        A[i, i] = -1 / h ** 2 * (beta((x[i] + x[i + 1]) / 2) + beta((x[i + 1] + x[i + 2]) / 2))
        A[i, i + 1] = beta((x[i + 1] + x[i + 2]) / 2) / h ** 2
        A[i, i - 1] = beta((x[i] + x[i + 1]) / 2) / h ** 2

    # 转换为 CSR 格式
    A_csr = A.tocsr()

    # construct B
    # regular points
    B = np.zeros(N - 1)
    B[0] = fun(x[1]) - u_0 * beta((x[0] + x[1]) / 2) / h ** 2
    B[N - 2] = fun(x[N-1]) - u_end * beta((x[N - 1] + x[N]) / 2) / h ** 2
    for i in range(1, N - 2):
        B[i] = fun(x[i+1])

    # 使用 PyAMG 求解
    ml = pyamg.ruge_stuben_solver(A_csr)  # 使用 CSR 格式的矩阵
    u_approx = ml.solve(B, tol=1e-10)  # 求解线性方程组

    # analytical solution
    u_analytical = np.zeros(N - 1)
    for i in range(N - 1):
        u_analytical[i] = fun_analytical(x[i + 1])

    # error
    # error = np.linalg.norm(u_approx - u_analytical) / np.linalg.norm(u_analytical)
    error = np.linalg.norm(u_approx - u_analytical, np.inf)
    return error

# List of N values to test
N_values = 20*np.logspace(0,8,9,base=2)
h_values = [1 / N for N in N_values]
errors = []

# Compute relative errors for different N values
for N in N_values:
    N=int(N)
    error = interface_order_drop(N)
    errors.append(error)
    print(f'N = {N}, h = {1 / N:.8f},  Error = {error:.10f}')

# Calculate convergence order
log_h = np.log(h_values)
log_E = np.log(errors)
slope, intercept, r_value, p_value, std_err = linregress(log_h, log_E)
print(f'Convergence order (slope): {slope:.4f}')
print(r_value)