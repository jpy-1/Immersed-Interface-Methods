#[u]!=0 and [\beta u_x]!=0
import numpy as np
import matplotlib.pyplot as plt
import pyamg
import time
import scipy.sparse as sp
from scipy.stats import linregress
# 设置 Matplotlib 字体以支持中文
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows 系统常用字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


def beta(t):
    if 0<=t<=1/2:
        result=1
    else:
        result=2
    return result
beta_plus=2 #beta>1/2
beta_minus=1 #beta<1/2

# define f(x)
def fun(t):# f(x)
    result=12*t**2
    return result

def fun_analytical(t):# analytical solution
    if 0<=t<=1/2:
        result=t**4-1.375*t
    else:
        result=t**4/2+0.3125*t+0.1875
    return result

# generate grid
N=100
x=np.linspace(0,1,N+1)
h=x[1]-x[0]

#define boundary conditions
u_0=0
u_end=1

#constrcut matrix A
#regular points
# A=np.zeros((N-1,N-1))
A = sp.lil_matrix((N-1, N-1))
A[0,0]=-1/h**2*(beta((x[0]+x[1])/2)+beta((x[1]+x[2])/2))
A[0,1]=(beta((x[1]+x[2])/2))/h**2
A[N-2,N-2]=-1/h**2*(beta((x[N-2]+x[N-1])/2)+beta((x[N-1]+x[N])/2))
A[N-2,N-3]=(beta((x[N-2]+x[N-1])/2))/h**2
for i in range(1,N-2):
    A[i,i]=-1/h**2*(beta((x[i]+x[i+1])/2)+beta((x[i+1]+x[i+2])/2))
    A[i,i+1]=beta((x[i+1]+x[i+2])/2)/h**2
    A[i,i-1]=beta((x[i]+x[i+1])/2)/h**2

# 转换为 CSR 格式
A_csr = A.tocsr()

#construct B
#regular points
B=np.zeros(N-1)
B[0]=fun(x[1])-u_0*beta((x[0]+x[1])/2)/h**2
B[N-2]=fun(x[N-1])-u_end*beta((x[N-1]+x[N])/2)/h**2
for i in range(1,N-2):
    B[i]=fun(x[i+1])

# 使用 PyAMG 求解
ml = pyamg.ruge_stuben_solver(A_csr)  # 使用 CSR 格式的矩阵
u_approx = ml.solve(B, tol=1e-10)  # 求解线性方程组

#analytical solution
u_analytical=np.zeros(N-1)
for i in range(N-1):
    u_analytical[i]=fun_analytical(x[i+1])

#error
# error=np.linalg.norm(u_approx-u_analytical)/np.linalg.norm(u_analytical)
error=np.linalg.norm(u_approx-u_analytical,np.inf)
print("error=",error)

#plot
plt.plot(x[1:N],u_approx,'r*',label='数值解')
plt.plot(x[1:N],u_analytical,'b-',label='解析解')
plt.legend()
plt.xlabel('x')
plt.ylabel('u')
plt.show()