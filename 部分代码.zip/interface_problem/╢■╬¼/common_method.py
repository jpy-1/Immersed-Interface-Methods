import numpy as np
from scipy.optimize import minimize
from scipy.sparse import lil_matrix, csc_matrix
from scipy.sparse.linalg import spsolve
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import LinearSegmentedColormap

# 设置 Matplotlib 字体以支持中文
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows 系统常用字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# [sigma]=0的情况
# 定义水平集函数，查找界面上离 (x, y) 最近的点
#边界条件x\in(-2,2), y \in (-2,2)，边值为0

#更换界面需要处理的函数：find_project_point（考虑初值）

def phi(x, y):
    return x ** 2 + 4*y ** 2 - 1  # phi(x, y) = 0 对应界面上的点

#beta的定义：
beta_plus=100
beta_minus=1
rou=beta_minus/beta_plus

def fun_beta(x,y):
    if phi(x,y)<=0:
        return beta_minus
    else:
        return beta_plus

#右侧源项
def fun_source_minus(x,y):
    return 0*beta_minus
def fun_source_plus(x,y):
    return (-2*np.sin(x)*np.cos(y))*beta_plus

def fun_source(x,y):
    if phi(x,y)<=0:
        return beta_minus*0
    else:
        return beta_plus*(-2*np.sin(x)*np.cos(y))

#方程的解析解
def fun_analysis_minus(x,y):
    return x**2-y**2

def fun_analysis_plus(x,y): #beta_minus=1
    return np.sin(x)*np.cos(y)

def fun_analysis(x,y):
    if phi(x,y)<=0:
        return fun_analysis_minus(x,y)
    else:
        return fun_analysis_plus(x,y)

#main函数：
#数值求解：
N=100
x=np.linspace(-2,2,N)
y=np.linspace(-2,2,N)
dx=x[1]-x[0]
dy=y[1]-y[0]

#系数矩阵与右侧向量的构造：
a_matrix=lil_matrix(((N-2)*(N-2),(N-2)*(N-2)))
b_vector=np.zeros((N-2)*(N-2))
for i in range(N-2):
    for j in range(N-2):
        x_point=x[i+1]
        y_point=y[j+1]
        #判断是否为规则点
        beta_point = fun_beta(x_point, y_point)
        a_matrix[i * (N - 2) + j, i * (N - 2) + j] = -2 * (1 / dx ** 2 + 1 / dy ** 2) * beta_point
        if i > 0:
            a_matrix[i * (N - 2) + j, (i - 1) * (N - 2) + j] = beta_point / dx ** 2
        if i < N - 3:
            a_matrix[i * (N - 2) + j, (i + 1) * (N - 2) + j] = beta_point / dx ** 2
        if j > 0:
            a_matrix[i * (N - 2) + j, i * (N - 2) + j - 1] = beta_point / dy ** 2
        if j < N - 3:
            a_matrix[i * (N - 2) + j, i * (N - 2) + j + 1] = beta_point / dy ** 2
        if i == 0 and j == 0:
            b_vector[i * (N - 2) + j] = fun_source(x_point, y_point) - \
                                        beta_point * fun_analysis(x[0], y[1]) / dx ** 2 - beta_point * fun_analysis(
                x[1], y[0]) / dy ** 2
        elif i == 0 and j == N - 3:
            b_vector[i * (N - 2) + j] = fun_source(x_point, y_point) - \
                                        beta_point * fun_analysis(x[0], y[N - 2]) / dx ** 2 - beta_point * fun_analysis(
                x[1], y[N - 1]) / dy ** 2
        elif i == N - 3 and j == 0:
            b_vector[i * (N - 2) + j] = fun_source(x_point, y_point) - \
                                        beta_point * fun_analysis(x[N - 1], y[1]) / dx ** 2 - beta_point * fun_analysis(
                x[N - 2], y[0]) / dy ** 2
        elif i == N - 3 and j == N - 3:
            b_vector[i * (N - 2) + j] = fun_source(x_point, y_point) - \
                                        beta_point * fun_analysis(x[N - 1],
                                                                  y[N - 2]) / dx ** 2 - beta_point * fun_analysis(
                x[N - 2], y[N - 1]) / dy ** 2

        elif i == 0:
            b_vector[i * (N - 2) + j] = fun_source(x_point, y_point) - beta_point * fun_analysis(x[0],
                                                                                                 y_point) / dx ** 2
        elif i == N - 3:
            b_vector[i * (N - 2) + j] = fun_source(x_point, y_point) - beta_point * fun_analysis(x[N - 1],
                                                                                                 y_point) / dx ** 2
        elif j == 0:
            b_vector[i * (N - 2) + j] = fun_source(x_point, y_point) - beta_point * fun_analysis(x_point,
                                                                                                 y[0]) / dy ** 2
        elif j == N - 3:
            b_vector[i * (N - 2) + j] = fun_source(x_point, y_point) - beta_point * fun_analysis(x_point,
                                                                                                 y[N - 1]) / dy ** 2
        else:
            b_vector[i * (N - 2) + j] = fun_source(x_point, y_point)

# 转换为 CSC 格式以提高求解效率
a_matrix = a_matrix.tocsc()

# 求解线性方程组
u_approx = spsolve(a_matrix, b_vector)


# 解析解
u_analysis=np.zeros((N-2)*(N-2))
for i in range(N-2):
    for j in range(N-2):
        x_point=x[i+1]
        y_point=y[j+1]
        u_analysis[i*(N-2)+j]=fun_analysis(x_point,y_point)

#无穷范数误差计算
error=np.linalg.norm(u_analysis - u_approx, ord=np.inf)
print("误差为：",error)

#二范数误差计算
error=np.linalg.norm(u_analysis - u_approx, ord=2)
print("误差为：",error)

#计算相对误差
relative_error=np.linalg.norm(u_analysis - u_approx, ord=2)/np.linalg.norm(u_analysis, ord=2)
print("相对误差为：",relative_error)

# 绘制解析解与数值解的对比图
# 结果可视化
X, Y = np.meshgrid(x[1:-1], y[1:-1])
u_approx = u_approx.reshape((N - 2, N - 2))
u_analysis = u_analysis.reshape((N - 2, N - 2))

fig = plt.figure(figsize=(10, 5))

ax1 = fig.add_subplot(121, projection='3d')
# 使用 'Reds' 颜色映射绘制近似解
# 自定义颜色映射：从黑色（最大值）到灰色（最小值）
colors = [(0, 0, 0), (0.5, 0.5, 0.5)]  # 黑色到灰色
custom_cmap = LinearSegmentedColormap.from_list("custom_gray", colors)

ax1.plot_surface(X, Y, u_approx, cmap=custom_cmap,edgecolor='none')
ax2 = fig.add_subplot(122, projection='3d')
ax1.set_title('近似解')
ax1.set_xlabel('x')
ax1.set_ylabel('y')
ax1.set_zlabel('u(x,y)')

ax2 = fig.add_subplot(122, projection='3d')
# 使用 'Blues' 颜色映射绘制解析解
ax2.plot_surface(X, Y, u_analysis, cmap=custom_cmap,edgecolor='none')
ax2.set_title('精确解')
ax2.set_xlabel('x')
ax2.set_ylabel('y')
ax2.set_zlabel('u(x,y)')

# 添加整体大标题
plt.suptitle('二维Poisson方程五点格式的数值解与解析解对比')
plt.show()