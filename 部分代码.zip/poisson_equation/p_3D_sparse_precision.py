import numpy as np
import matplotlib.pyplot as plt
import pyamg
import scipy.sparse as sp
import time
from scipy.stats import linregress
import pandas as pd
from tabulate import tabulate
#record the start time
# -Delta{u}=f(x)
# Delta{u}=-f(x)
# Define the function f(x)
def fun(t1,t2,t3):
    result=-2*np.pi**2*np.cos(2*np.pi*t1)*(np.sin(np.pi*t2))**2*(np.sin(np.pi*t3))**2\
        -2*np.pi**2*(np.sin(np.pi*t1))**2*np.cos(2*np.pi*t2)*(np.sin(np.pi*t3))**2 \
        -2*np.pi**2*(np.sin(np.pi*t1))**2*(np.sin(np.pi*t2))**2*np.cos(2*np.pi*t3)
    return -1*result

#define analytic solution
def fun_exact(t1,t2,t3) :
    result=(np.sin(np.pi*t1))**2*(np.sin(np.pi*t2))**2*(np.sin(np.pi*t3))**2
    return result

def poisson_3d(N):
    start_time = time.time()
    # define subscript from 0 to N
    x = np.linspace(0, 1, N + 1)
    y = np.linspace(0, 1, N + 1)
    z = np.linspace(0, 1, N + 1)
    dx = x[1] - x[0]
    dy = y[1] - y[0]
    dz = z[1] - z[0]

    # construct the matrix A and B  AV=B

    # construct C matrix
    b = 2 * dz ** 2 * (1 / dx ** 2 + 1 / dy ** 2 + 1 / dz ** 2)
    C1 = -b * sp.eye(N - 1, format='csr')
    C2 = sp.diags(np.ones(N - 2), offsets=-1, shape=(N - 1, N - 1), format='csr')
    C3 = sp.diags(np.ones(N - 2), offsets=1, shape=(N - 1, N - 1), format='csr')
    C = C1 + C2 + C3

    # construct D matrix
    D1 = sp.kron(sp.eye(N - 1, format='csr'), C)
    D2 = sp.kron(sp.diags(np.ones(N - 2), offsets=1, shape=(N - 1, N - 1), format='csr'),
                 (dz / dy) ** 2 * sp.eye(N - 1, format='csr'))
    D3 = sp.kron(sp.diags(np.ones(N - 2), offsets=-1, shape=(N - 1, N - 1), format='csr'),
                 (dz / dy) ** 2 * sp.eye(N - 1, format='csr'))
    D = D1 + D2 + D3

    # #construct A matrix
    A1 = sp.kron(sp.eye(N - 1, format='csr'), D)
    A2 = sp.kron(sp.diags(np.ones(N - 2), offsets=1, shape=(N - 1, N - 1), format='csr'),
                 (dz / dx) ** 2 * sp.eye((N - 1) * (N - 1), format='csr'))
    A3 = sp.kron(sp.diags(np.ones(N - 2), offsets=-1, shape=(N - 1, N - 1), format='csr'),
                 (dz / dx) ** 2 * sp.eye((N - 1) * (N - 1), format='csr'))
    A = A1 + A2 + A3

    # construct B matrix
    B = np.zeros((N - 1) * (N - 1) * (N - 1))
    for i in range(N - 1):
        for j in range(N - 1):
            for k in range(N - 1):
                B[i * (N - 1) * (N - 1) + j * (N - 1) + k] = dz ** 2 * fun(x[i + 1], y[j + 1], z[k + 1])

    # create AMG solver
    m1 = pyamg.ruge_stuben_solver(A)
    # solve linear system using AMG
    u_approx = m1.solve(B, tol=1e-10)

    # calculate the analytic solution
    u_exact = np.zeros((N - 1) * (N - 1) * (N - 1))
    for i in range(N - 1):
        for j in range(N - 1):
            for k in range(N - 1):
                u_exact[i * (N - 1) * (N - 1) + j * (N - 1) + k] = fun_exact(x[i + 1], y[j + 1], z[k + 1])

    # error calculation
    # error = np.linalg.norm(u_approx - u_exact) / np.linalg.norm(u_exact)
    error = np.linalg.norm(u_exact - u_approx, ord=np.inf)

    # record the end time
    end_time = time.time()
    # calculate the total time taken
    total_time = end_time - start_time
    return error

# List of N values to test
N_values = 10*np.logspace(0,3,8,base=2)
h_values = [1 / N for N in N_values]
errors = []

# Compute relative errors for different N values
for N in N_values:
    N=int(N)
    error = poisson_3d(N)
    errors.append(error)
    print(f'N = {N}, h = {1 / N:.8f},  Error = {error:.10f}')

# Calculate convergence order
log_h = np.log(h_values)
log_E = np.log(errors)
slope, intercept, r_value, p_value, std_err = linregress(log_h, log_E)
print(f'Convergence order (slope): {slope:.4f}')
print(r_value)

data={
    'N':N_values,
    'h':h_values,
    'E':errors,
}
df=pd.DataFrame(data)
latex_table=tabulate(df,headers='keys',tablefmt='latex_booktabs',showindex=False)
print(latex_table)