import numpy as np
import matplotlib.pyplot as plt
import pyamg
import scipy.sparse as sp
import time
#record the start time
start_time = time.time()
# -Delta{u}=f(x)

#define f(x，y)
def fun(t1,t2):
    result=-2*np.pi**2*np.cos(2*np.pi*t1)*(np.sin(np.pi*t2))**2-\
        2*np.pi**2*(np.sin(np.pi*t1))**2*np.cos(2*np.pi*t2)
    return result

#define analytical solution
def fun_exact(t1,t2):
    result=(np.sin(np.pi*t1))**2*(np.sin(np.pi*t2))**2
    return result

#initial condition
h=0.001 #step size
x=np.arange(0,1,h)
x=np.append(x,1)
y=np.arange(0,1,h)
y=np.append(y,1)
u_approx=np.ones((len(x),len(y)))
u_approx[0,:]=0
u_approx[-1,:]=0
u_approx[:,0]=0
u_approx[:,-1]=0
#u_approx_vector=u_approx.reshape(1,u_approx.size,order='F')

#construct matrix A and vector b
B=np.zeros((len(x),len(x)))
for i in range(len(x)):
    B[i,i]=4
for j in range(len(x)-1):
    B[j,j+1]=-1
    B[j+1,j]=-1
A_1=np.kron(np.eye(len(y)),B) #main diagonal
A_2=np.kron(np.diag(np.ones(len(y)-1),1),-np.eye(len(x)))#upper secondary diagonal
A_3=np.kron(np.diag(np.ones(len(y)-1),-1),-np.eye(len(x)))#lower secondary diagonal
A=A_1+A_2+A_3# coefficient matrix
b=np.zeros(len(x)*len(y))
for i in range(len(y)):
    for j in range(len(x)):
        b[i*len(x)+j]=h**2*fun(x[j],y[i])

# #solve linear system
# u_approx=np.linalg.solve(A,b)

#create AMG solver
A_csr = sp.csr_matrix(A)
m1=pyamg.ruge_stuben_solver(A_csr)
#solve linear system using AMG
u_approx=m1.solve(b, tol=1e-10)
u_approx=u_approx.reshape(len(x),len(y),order='F')

#exact solution
u_exact=np.zeros((len(x),len(y)))
for i in range(len(y)):
    for j in range(len(x)):
        u_exact[i,j]=fun_exact(x[j],y[i])

#plot results
fig,ax=plt.subplots(1,2,figsize=(10,5))
im1=ax[0].imshow(u_approx,cmap='jet',extent=[0,1,0,1])
ax[0].set_title('Approximate solution')
ax[0].set_xlabel('x')
ax[0].set_ylabel('y')
fig.colorbar(im1,ax=ax[0])
im2=ax[1].imshow(u_exact,cmap='jet',extent=[0,1,0,1])
ax[1].set_title('Exact solution')
ax[1].set_xlabel('x')
ax[1].set_ylabel('y')
fig.colorbar(im2,ax=ax[1])
plt.show()

#calculate error
error=np.linalg.norm(u_exact-u_approx)/np.linalg.norm(u_exact)
print('error:',error)

#record the end time
end_time = time.time()
#calculate the total time taken
total_time = end_time - start_time
print('Total time taken:',total_time)