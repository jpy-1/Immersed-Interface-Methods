import numpy as np
import matplotlib.pyplot as plt
import pyamg
import scipy.sparse as sp
import time
#record the start time
start_time = time.time()
# -Delta{u}=f(x)
# Delta{u}=-f(x)
# Define the function
def fun(t1,t2,t3):
    result=-2*np.pi**2*np.cos(2*np.pi*t1)*(np.sin(np.pi*t2))**2*(np.sin(np.pi*t3))**2\
        -2*np.pi**2*(np.sin(np.pi*t1))**2*np.cos(2*np.pi*t2)*(np.sin((np.pi*t3)**2))**2 \
        -2*np.pi**2*(np.sin(np.pi*t1))**2*(np.sin(np.pi*t2))**2*np.cos(2*np.pi*t3)
    return -1*result
#define analytic solution
def fun_exact(t1,t2,t3) :
    result=(np.sin(np.pi*t1))**2*(np.sin(np.pi*t2))**2*(np.sin(np.pi*t3))**2
    return result

#initial conditions
N=9#number of grid points
#define subscript from 0 to N
x=np.linspace(0,1,N+1)
y=np.linspace(0,1,N+1)
z=np.linspace(0,1,N+1)
dx=x[1]-x[0]
dy=y[1]-y[0]
dz=z[1]-z[0]

#construct the matrix A and B  AV=B

#construct C matrix
b=2*dz**2*(1/dx**2+1/dy**2+1/dz**2)
C=np.zeros((N+1,N+1))
C[0,0]=1
C[-1,-1]=1
for  i in range(1,N):
    C[i,i-1]=1
    C[i,i]=-b
    C[i,i+1]=1
#construct D matrix
I1=np.eye(N+1)
I1[0,0]=0
I1[-1,-1]=0
D1=np.kron(I1,C)
for i in range(N+1):
    D1[i,i]=1
    D1[i+N*(N+1),i+N*(N+1)]=1
D2=np.kron(np.diag(np.ones(N),1),(dz/dy)**2*np.eye(N+1))
D3=np.kron(np.diag(np.ones(N),-1),(dz/dy)**2*np.eye(N+1))
D=D1+D2+D3

#construct A matrix
A1=np.kron(I1,D)
for i in range((N+1)*(N+1)):
    A1[i,i]=1
    A1[i+N*(N+1)*(N+1),i+N*(N+1)*(N+1)]=1
A2=np.kron(np.diag(np.ones(N),1),(dz/dx)**2*np.eye((N+1)*(N+1)))
A3=np.kron(np.diag(np.ones(N),-1),(dz/dx)**2*np.eye((N+1)*(N+1)))
A=A1+A2+A3

#construct B matrix
B=np.zeros((N+1)*(N+1)*(N+1))
for i in range(1,N):
    for j in range(1,N):
        for k in range(1,N):
            B[i*(N+1)*(N+1)+j*(N+1)+k]=dz**2*fun(x[i],y[j],z[k])

#solve the system
u_approx=np.linalg.solve(A,B)

#calculate the analytic solution
u_exact=np.zeros((N+1)*(N+1)*(N+1))
for i in range(0,N+1):
    for j in range(1,N+1):
        for k in range(1,N+1):
            u_exact[i*(N+1)*(N+1)+j*(N+1)+k]=fun_exact(x[i],y[j],z[k])
#error calculation
error=np.linalg.norm(u_approx-u_exact)/np.linalg.norm(u_exact)
print("Error is:",error)

#plot the solution
horizon=np.linspace(0,1,(N+1)**3)
plt.plot(horizon,u_approx,label="Approximate solution")
plt.plot(horizon,u_exact,label="Analytic solution")
plt.legend()
plt.show()

#record the end time
end_time = time.time()
#calculate the total time taken
total_time = end_time - start_time
print('Total time taken:',total_time)

