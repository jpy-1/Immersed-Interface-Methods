import numpy as np
import matplotlib.pyplot as plt
import pyamg
import scipy.sparse as sp
import time
# 设置 Matplotlib 字体以支持中文
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows 系统常用字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

#record the start time
start_time = time.time()

# -Delta{u}=f(x)

#define f(x)
def fun(t):# f(x)
    result=np.pi**2*np.sin(np.pi*t)
    return -1*result
#define analytical solution
def fun_exact(t):# exact solution
    result=np.sin(np.pi*t)
    return result

#initial condition
N=40#number of grid points
#define subscript from 0 to N
x=np.linspace(0,1,N+1)
dx=x[1]-x[0]

# constructing matrix A and vector B
A1=-2*np.eye(N-1)
A2=np.diag(np.ones(N-2),-1)
A3=np.diag(np.ones(N-2),1)
A=A1+A2+A3

B=np.zeros(N-1)
for i in range(N-1):
    B[i]=dx**2*fun(x[i+1])

#create AMG solver
A_csr = sp.csr_matrix(A)
m1=pyamg.ruge_stuben_solver(A_csr)
#solve linear system using AMG
u_approx=m1.solve(B, tol=1e-10)

#analytical solution
u_exact=np.zeros(N-1)
for i in range(N-1):
    u_exact[i]=fun_exact(x[i+1])

# error calculation
error=np.linalg.norm(u_approx-u_exact)/np.linalg.norm(u_exact)
print('Error:',error)

#record the end time
end_time = time.time()
#calculate the total time taken
total_time = end_time - start_time
print('Total time taken:',total_time)

#plot the solution
plt.plot(x[1:-1],u_approx,'r-',label='近似解')
plt.plot(x[1:-1],u_exact,'b+',label='解析解')
#将图例放在右上角，并小一点
plt.gca().legend(loc='upper right',fontsize=8.5)
plt.title('一维Poisson方程的三点格式差分求解')
plt.xlabel('x')
plt.ylabel('u(x)')
plt.show()