import numpy as np
import matplotlib.pyplot as plt
import pyamg
import scipy.sparse as sp
import time
#record the start time
start_time = time.time()
# -Delta{u}=f(x)

#define f(x，y)
def fun(t1,t2):
    result=-2*np.pi**2*np.cos(2*np.pi*t1)*(np.sin(np.pi*t2))**2-\
        2*np.pi**2*(np.sin(np.pi*t1))**2*np.cos(2*np.pi*t2)
    return -1*result

#define analytical solution
def fun_exact(t1,t2):
    result=(np.sin(np.pi*t1))**2*(np.sin(np.pi*t2))**2
    return result

#initial condition
N=20#number of grid points
#define subscript from 0 to N
x=np.linspace(0,1,N+1)
y=np.linspace(0,1,N+1)
dx=x[1]-x[0]
dy=y[1]-y[0]

#construct matrix A and vector B
b=2*dy**2*(1/dx**2+1/dy**2)
C1=-b*np.eye(N-1)
C2=np.diag(np.ones(N-2),-1)
C3=np.diag(np.ones(N-2),1)
C=C1+C2+C3

#construct A matrix
A1=np.kron(np.eye(N-1),C)
A2=np.kron(np.diag(np.ones(N-2),1),(dy/dx)**2*np.eye(N-1))
A3=np.kron(np.diag(np.ones(N-2),-1),(dy/dx)**2*np.eye(N-1))
A=A1+A2+A3

#construct vector B
B=np.zeros((N-1)*(N-1))
for i in range(N-1):
    for j in range(N-1):
            B[i*(N-1)+j]=dy**2*fun(x[i+1],y[j+1])

#create AMG solver
A_csr = sp.csr_matrix(A)
m1=pyamg.ruge_stuben_solver(A_csr)
#solve linear system using AMG
u_approx=m1.solve(B,tol=1e-10)

#exact solution
u_exact=np.zeros((N-1)*(N-1))
for i in range(N-1):
    for j in range(N-1):
        u_exact[i*(N-1)+j]=fun_exact(x[i+1],y[j+1])

#calculate error
error=np.linalg.norm(u_exact-u_approx)/np.linalg.norm(u_exact)
print('error:',error)

#record the end time
end_time = time.time()
#calculate the total time taken
total_time = end_time - start_time
print('Total time taken:',total_time)