import numpy as np
import matplotlib.pyplot as plt
import pyamg
import scipy.sparse as sp
import time
#record the start time
start_time = time.time()

# -Delta{u}=f(x)

#define f(x)
def fun(t):# f(x)
    result=np.pi**2*np.sin(np.pi*t)
    return result
#define analytical solution
def fun_exact(t):# exact solution
    result=np.sin(np.pi*t)
    return result

#initial condition
h=0.01 #step size
u_0=0
u_end=0
x=np.arange(0,1,h)
x=np.append(x,1)

# constructing matrix A and vector b
A=np.zeros((len(x)-2,len(x)-2))
b=np.zeros((len(x)-2,1))
for i in range(len(x)-2):
    A[i][i]=2
for i in range(len(x)-3):
    A[i][i+1]=-1
    A[i+1][i]=-1
for i in range(len(x)-2):
    b[i]=h**2*fun(x[i+1])
b[0]+=u_0
b[-1]+=u_end

# solving linear system
# u_approx=np.linalg.solve(A,b) # approximated solution

#create AMG solver
A_csr = sp.csr_matrix(A)
m1=pyamg.ruge_stuben_solver(A_csr)
#solve linear system using AMG
u_approx=m1.solve(b, tol=1e-10)

#insert boundary conditions
u_approx=np.insert(u_approx, 0,u_0)
u_approx=np.append(u_approx,u_end)

#exact solution
u_exact=np.zeros(len(x))
for i in range(len(x)):
    u_exact[i]=fun_exact(x[i])

# plotting
plt.title('Approximation of u(x) using finite differences')
plt.plot(x,u_approx,'r*',label='Approximated solution')
plt.plot(x,u_exact,'b-',label='Exact solution')
plt.xlabel('x')
plt.ylabel('u(x)')
plt.legend()
plt.show()

# error calculation
error=np.linalg.norm(u_approx-u_exact)/np.linalg.norm(u_exact)
print('Error:',error)

#record the end time
end_time = time.time()
#calculate the total time taken
total_time = end_time - start_time
print('Total time taken:',total_time)