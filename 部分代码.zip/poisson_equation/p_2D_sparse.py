import numpy as np
import matplotlib.pyplot as plt
import pyamg
import scipy.sparse as sp
import time
from mpl_toolkits.mplot3d import Axes3D

# 设置 Matplotlib 字体以支持中文
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows 系统常用字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

#record the start time
start_time = time.time()
# -Delta{u}=f(x)

#define f(x，y)
def fun(t1,t2):
    result=-2*np.pi**2*np.cos(2*np.pi*t1)*(np.sin(np.pi*t2))**2-\
        2*np.pi**2*(np.sin(np.pi*t1))**2*np.cos(2*np.pi*t2)
    return -1*result

#define analytical solution
def fun_exact(t1,t2):
    result=(np.sin(np.pi*t1))**2*(np.sin(np.pi*t2))**2
    return result

#initial condition
N=100#number of grid points
#define subscript from 0 to N
x=np.linspace(0,1,N+1)
y=np.linspace(0,1,N+1)
dx=x[1]-x[0]
dy=y[1]-y[0]

#construct matrix A and vector B
b=2*dy**2*(1/dx**2+1/dy**2)
C1=-b*sp.eye(N-1,format='csr')
C2=sp.diags(np.ones(N-2),offsets=-1,shape=(N-1,N-1),format='csr')
C3=sp.diags(np.ones(N-2),offsets=1,shape=(N-1,N-1),format='csr')
C=C1+C2+C3

#construct A matrix
A1=sp.kron(sp.eye(N-1,format='csr'),C)
A2=sp.kron(sp.diags(np.ones(N-2),offsets=1,shape=(N-1,N-1),format='csr'),(dy/dx)**2*sp.eye(N-1,format='csr'))
A3=sp.kron(sp.diags(np.ones(N-2),offsets=-1,shape=(N-1,N-1),format='csr'),(dy/dx)**2*sp.eye(N-1,format='csr'))
A=A1+A2+A3

#construct vector B
B=np.zeros((N-1)*(N-1))
for i in range(N-1):
    for j in range(N-1):
            B[i*(N-1)+j]=dy**2*fun(x[i+1],y[j+1])

#create AMG solver
m1=pyamg.ruge_stuben_solver(A)
#solve linear system using AMG
u_approx=m1.solve(B,tol=1e-10)

#exact solution
u_exact=np.zeros((N-1)*(N-1))
for i in range(N-1):
    for j in range(N-1):
        u_exact[i*(N-1)+j]=fun_exact(x[i+1],y[j+1])

#calculate error
error=np.linalg.norm(u_exact-u_approx)/np.linalg.norm(u_exact)
print('error:',error)

#record the end time
end_time = time.time()
#calculate the total time taken
total_time = end_time - start_time
print('Total time taken:',total_time)

# 结果可视化
X, Y = np.meshgrid(x[1:-1], y[1:-1])
U_approx = u_approx.reshape((N - 1, N - 1))
U_exact = u_exact.reshape((N - 1, N - 1))

fig = plt.figure(figsize=(10, 5))

ax1 = fig.add_subplot(121, projection='3d')
# 使用 'Reds' 颜色映射绘制近似解
ax1.plot_surface(X, Y, U_approx, cmap='rainbow')
ax2 = fig.add_subplot(122, projection='3d')
ax1.set_title('近似解')
ax1.set_xlabel('x')
ax1.set_ylabel('y')
ax1.set_zlabel('u(x,y)')

ax2 = fig.add_subplot(122, projection='3d')
# 使用 'Blues' 颜色映射绘制解析解
ax2.plot_surface(X, Y, U_exact, cmap='Spectral')
ax2.set_title('精确解')
ax2.set_xlabel('x')
ax2.set_ylabel('y')
ax2.set_zlabel('u(x,y)')

# 添加整体大标题
plt.suptitle('二维Poisson方程五点格式的数值解与解析解对比')
plt.show()
